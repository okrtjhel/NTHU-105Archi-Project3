#ifndef _LIBRARIES_H
#define _LIBRARIES_H

#include "instruction.h"
#include "regfile.h"
#include "memory.h"
#include "cmp.h"

#endif